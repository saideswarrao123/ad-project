export const vehicleCategories = [
  { id: "2w", name: "2 Wheelers", icon: "🏍️", desc: "Motorcycles & Scooters" },
  { id: "4w", name: "4 Wheelers", icon: "🚗", desc: "Cars, SUVs & Sedans" },
  { id: "mw", name: "Multi Wheelers", icon: "🚛", desc: "Heavy & Commercial Vehicles" },
];

export const companies: Record<string, { id: string; name: string }[]> = {
  "2w": [
    { id: "hero", name: "Hero" },
    { id: "honda-2w", name: "Honda" },
    { id: "suzuki-2w", name: "Suzuki" },
    { id: "yamaha", name: "Yamaha" },
    { id: "bajaj", name: "Bajaj" },
    { id: "tvs", name: "TVS" },
  ],
  "4w": [
    { id: "honda-4w", name: "Honda" },
    { id: "toyota", name: "Toyota" },
    { id: "tata", name: "Tata" },
    { id: "hyundai", name: "Hyundai" },
    { id: "mahindra", name: "Mahindra" },
    { id: "suzuki-4w", name: "Suzuki" },
  ],
  "mw": [
    { id: "ashok-leyland", name: "Ashok Leyland" },
    { id: "tata-mw", name: "Tata Motors" },
    { id: "mahindra-mw", name: "Mahindra" },
    { id: "eicher", name: "Eicher" },
    { id: "bharat-benz", name: "BharatBenz" },
  ],
};

export const models: Record<string, string[]> = {
  hero: ["Splendor", "Glamour", "Passion", "HF Deluxe", "Xtreme 160R"],
  "honda-2w": ["Shine", "Unicorn", "Hornet", "SP125", "Activa"],
  "suzuki-2w": ["Access", "Gixxer", "Burgman", "Intruder"],
  yamaha: ["FZ", "R15", "MT-15", "Ray ZR"],
  bajaj: ["Pulsar", "Dominar", "Platina", "CT100"],
  tvs: ["Apache", "Jupiter", "Ntorq", "Raider"],
  "honda-4w": ["City", "Amaze", "Elevate", "WR-V"],
  toyota: ["Fortuner", "Innova", "Glanza", "Urban Cruiser"],
  tata: ["Nexon", "Harrier", "Safari", "Punch", "Altroz"],
  hyundai: ["Creta", "Venue", "i20", "Verna", "Tucson"],
  mahindra: ["Thar", "Scorpio", "XUV700", "Bolero", "XUV300"],
  "suzuki-4w": ["Swift", "Brezza", "Baleno", "Grand Vitara"],
  "ashok-leyland": ["Dost", "Boss", "Captain", "Ecomet"],
  "tata-mw": ["Prima", "Ultra", "Signa", "Ace"],
  "mahindra-mw": ["Blazo", "Furio", "Jayo"],
  eicher: ["Pro 2000", "Pro 3000", "Pro 6000"],
  "bharat-benz": ["1217C", "1617R", "3523R"],
};

const partNames = [
  "Brake Pad Set", "Oil Filter", "Air Filter", "Spark Plug", "Clutch Plate",
  "Chain Sprocket Kit", "Head Gasket", "Piston Ring Set", "Fuel Pump", "Radiator Cap",
  "Timing Belt", "Water Pump", "Alternator", "Starter Motor", "Shock Absorber",
  "Ball Joint", "Tie Rod End", "CV Joint", "Wheel Bearing", "Brake Disc",
  "Brake Drum", "Clutch Cable", "Throttle Cable", "Speedometer Cable", "Battery Terminal",
  "Ignition Coil", "Distributor Cap", "Rotor Arm", "Fan Belt", "Power Steering Pump",
  "Fuel Injector", "Oxygen Sensor", "Camshaft Sensor", "Crankshaft Sensor", "MAP Sensor",
  "Thermostat", "Heater Core", "AC Compressor", "Condenser", "Blower Motor",
  "Wiper Blade Set", "Headlight Bulb", "Tail Light Assembly", "Side Mirror", "Door Handle",
  "Window Regulator", "Exhaust Gasket", "Muffler", "Catalytic Converter", "Drive Belt"
];

export interface Product {
  id: string;
  name: string;
  code: string;
  prefCode: string;
  price: number;
  desc: string;
}

export const generateProducts = (): Product[] => {
  return partNames.map((name, i) => {
    const num = String(i + 1).padStart(3, "0");
    return {
      id: `part-${num}`,
      name,
      code: `DBC-${4000 + i}-${i % 2 === 0 ? "FR" : "RR"}`,
      prefCode: `AKE-${name.substring(0, 2).toUpperCase()}${4000 + i}`,
      price: Math.floor(150 + Math.random() * 4850),
      desc: `High-quality ${name.toLowerCase()} for your vehicle. OEM compatible, includes mounting hardware.`,
    };
  });
};
