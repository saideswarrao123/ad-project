import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { ShoppingCart, LogOut, Home, Package } from "lucide-react";

const Navbar = () => {
  const { user, logout } = useAuth();
  const { count, cartPop } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="sticky top-0 z-50 h-16 bg-card border-b border-border backdrop-blur-sm">
      <div className="container h-full flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <span className="text-primary text-xl font-bold tracking-tight">⚙ AutoParts</span>
        </Link>

        {user && (
          <div className="flex items-center gap-1 sm:gap-4">
            <Link to="/" className="flex items-center gap-1.5 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground transition-colors">
              <Home size={18} />
              <span className="hidden sm:inline">Home</span>
            </Link>
            <Link to="/products" className="flex items-center gap-1.5 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground transition-colors">
              <Package size={18} />
              <span className="hidden sm:inline">Products</span>
            </Link>
            <Link to="/cart" className="relative flex items-center gap-1.5 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ShoppingCart size={18} />
              {count > 0 && (
                <span className={`absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center ${cartPop ? "animate-pop" : ""}`}>
                  {count}
                </span>
              )}
            </Link>
            <button onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-2 rounded-md text-sm text-muted-foreground hover:text-foreground transition-colors">
              <LogOut size={18} />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
