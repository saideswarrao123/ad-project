import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";

const methods = [
  { id: "upi", name: "UPI", desc: "Google Pay, PhonePe, Paytm" },
  { id: "card", name: "Credit / Debit Card", desc: "Visa, Mastercard, RuPay" },
  { id: "netbanking", name: "Net Banking", desc: "All major banks" },
  { id: "cod", name: "Cash on Delivery", desc: "Pay when you receive" },
];

const Payment = () => {
  const [selected, setSelected] = useState("upi");
  const { total, clearCart } = useCart();
  const navigate = useNavigate();

  const handlePay = () => {
    clearCart();
    navigate("/order-success");
  };

  return (
    <div className="container py-8 max-w-lg animate-fade-in">
      <h1 className="text-3xl font-semibold mb-2">Payment.</h1>
      <p className="text-muted-foreground mb-8">Total: <span className="text-foreground font-bold">₹{total.toLocaleString()}</span></p>

      <div className="space-y-3 mb-8">
        {methods.map(m => (
          <button
            key={m.id}
            onClick={() => setSelected(m.id)}
            className={`w-full bg-card rounded-xl p-4 text-left transition-all ${
              selected === m.id ? "ring-2 ring-primary" : "card-hover"
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-4 h-4 rounded-full border-2 ${selected === m.id ? "border-primary bg-primary" : "border-muted-foreground"}`} />
              <div>
                <h3 className="font-semibold text-sm">{m.name}</h3>
                <p className="text-xs text-muted-foreground">{m.desc}</p>
              </div>
            </div>
          </button>
        ))}
      </div>

      <button onClick={handlePay} className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg btn-press">
        Place Order — ₹{total.toLocaleString()}
      </button>
    </div>
  );
};

export default Payment;
