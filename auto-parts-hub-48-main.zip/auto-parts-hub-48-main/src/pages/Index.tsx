import { useNavigate } from "react-router-dom";
import { vehicleCategories } from "@/data/vehicleData";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="container py-12">
      <h1 className="text-3xl sm:text-4xl font-semibold mb-2">Select Vehicle Type.</h1>
      <p className="text-muted-foreground mb-8">Choose your vehicle category to find the right parts.</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {vehicleCategories.map((cat, i) => (
          <button
            key={cat.id}
            onClick={() => navigate(`/companies/${cat.id}`)}
            className="bg-card rounded-xl p-8 text-left card-hover animate-fade-in"
            style={{ animationDelay: `${i * 100}ms` }}
          >
            <span className="text-5xl block mb-4">{cat.icon}</span>
            <h2 className="text-xl font-semibold mb-1">{cat.name}</h2>
            <p className="text-sm text-muted-foreground">{cat.desc}</p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Index;
