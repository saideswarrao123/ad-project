import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Register = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setError("Passwords do not match."); return; }
    if (password.length < 4) { setError("Password must be at least 4 characters."); return; }
    if (register(username, password)) {
      navigate("/login");
    } else {
      setError("Username already exists.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm animate-fade-in">
        <div className="text-center mb-8">
          <span className="text-primary text-3xl font-bold">⚙ AutoParts</span>
          <h1 className="text-2xl font-semibold mt-4">Create Account.</h1>
          <p className="text-muted-foreground mt-1 text-sm">Register to start ordering parts</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-destructive text-sm text-center">{error}</p>}
          <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} className="input-industrial w-full text-foreground" required />
          <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="input-industrial w-full text-foreground" required />
          <input type="password" placeholder="Confirm Password" value={confirm} onChange={e => setConfirm(e.target.value)} className="input-industrial w-full text-foreground" required />
          <button type="submit" className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg btn-press">
            Create Account
          </button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-primary hover:underline">Sign In</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
