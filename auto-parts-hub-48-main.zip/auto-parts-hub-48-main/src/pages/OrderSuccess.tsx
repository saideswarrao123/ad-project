import { useNavigate } from "react-router-dom";
import { CheckCircle } from "lucide-react";

const OrderSuccess = () => {
  const navigate = useNavigate();

  return (
    <div className="container py-20 text-center animate-fade-in">
      <CheckCircle size={64} className="mx-auto text-green-500 mb-4" />
      <h1 className="text-3xl font-semibold mb-2">Order Placed Successfully.</h1>
      <p className="text-muted-foreground mb-8">Your spare parts are on their way. Thank you for your order.</p>
      <button onClick={() => navigate("/")} className="bg-primary text-primary-foreground font-semibold px-6 py-3 rounded-lg btn-press">
        Back to Home
      </button>
    </div>
  );
};

export default OrderSuccess;
