import { useNavigate } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";
import { Trash2, ShoppingCart } from "lucide-react";

const Cart = () => {
  const { items, removeItem, total, count } = useCart();
  const navigate = useNavigate();

  if (count === 0) {
    return (
      <div className="container py-20 text-center animate-fade-in">
        <ShoppingCart size={48} className="mx-auto text-muted-foreground mb-4" />
        <h1 className="text-2xl font-semibold mb-2">Cart is empty.</h1>
        <p className="text-muted-foreground mb-6">Browse parts and add them to your cart.</p>
        <button onClick={() => navigate("/products")} className="bg-primary text-primary-foreground font-semibold px-6 py-3 rounded-lg btn-press">
          Browse Parts
        </button>
      </div>
    );
  }

  return (
    <div className="container py-8 animate-fade-in">
      <h1 className="text-3xl font-semibold mb-6">Your Cart.</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-3">
          {items.map(item => (
            <div key={item.id} className="bg-card rounded-xl p-4 flex items-center gap-4">
              <div className="bg-accent rounded-lg w-16 h-16 flex items-center justify-center shrink-0">
                <span className="text-xl">⚙</span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm">{item.name}</h3>
                <p className="label-code text-muted-foreground text-xs">{item.code}</p>
                <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="font-bold">₹{(item.price * item.quantity).toLocaleString()}</p>
                <button onClick={() => removeItem(item.id)} className="text-destructive hover:text-destructive/80 mt-1 transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-card rounded-xl p-6 h-fit sticky top-24">
          <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>Items ({count})</span>
            <span>₹{total.toLocaleString()}</span>
          </div>
          <div className="border-t border-border my-4" />
          <div className="flex justify-between font-bold text-lg mb-6">
            <span>Total</span>
            <span>₹{total.toLocaleString()}</span>
          </div>
          <button onClick={() => navigate("/payment")} className="w-full bg-primary text-primary-foreground font-semibold py-3 rounded-lg btn-press">
            Proceed to Payment
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
