import { useState, useMemo } from "react";
import { generateProducts } from "@/data/vehicleData";
import { useCart } from "@/contexts/CartContext";
import { Search, ShoppingCart, Check } from "lucide-react";
import { toast } from "sonner";

const products = generateProducts();

const Products = () => {
  const [search, setSearch] = useState("");
  const { addItem } = useCart();
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return products;
    return products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.code.toLowerCase().includes(q) ||
      p.prefCode.toLowerCase().includes(q)
    );
  }, [search]);

  const handleAdd = (p: typeof products[0]) => {
    addItem({ id: p.id, name: p.name, code: p.code, price: p.price });
    setAddedIds(prev => new Set(prev).add(p.id));
    toast.success(`${p.name} added to cart`);
    setTimeout(() => setAddedIds(prev => { const n = new Set(prev); n.delete(p.id); return n; }), 1500);
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-semibold mb-6">Spare Parts.</h1>

      <div className="sticky top-16 z-40 bg-background pb-4 pt-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
          <input
            type="text"
            placeholder="Search by name, code, or preferable code..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="input-industrial w-full pl-10 text-foreground"
          />
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-4">{filtered.length} parts found</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((p, i) => (
          <div key={p.id} className="bg-card rounded-xl p-4 card-hover flex flex-col animate-fade-in" style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}>
            <div className="bg-accent rounded-lg h-32 flex items-center justify-center mb-3">
              <span className="text-3xl text-muted-foreground">⚙</span>
            </div>
            <h3 className="font-semibold text-sm mb-1">{p.name}</h3>
            <div className="flex gap-2 mb-1">
              <span className="label-code text-muted-foreground text-xs">{p.code}</span>
              <span className="label-code text-primary text-xs">{p.prefCode}</span>
            </div>
            <p className="text-xs text-muted-foreground mb-3 line-clamp-2 flex-1">{p.desc}</p>
            <div className="flex items-center justify-between mt-auto">
              <span className="font-bold text-lg">₹{p.price.toLocaleString()}</span>
              <button
                onClick={() => handleAdd(p)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold btn-press transition-colors ${
                  addedIds.has(p.id)
                    ? "bg-green-600 text-primary-foreground"
                    : "bg-primary text-primary-foreground"
                }`}
              >
                {addedIds.has(p.id) ? <Check size={16} /> : <ShoppingCart size={16} />}
                {addedIds.has(p.id) ? "Added" : "Add"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
