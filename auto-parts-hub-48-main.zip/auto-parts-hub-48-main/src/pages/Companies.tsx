import { useParams, useNavigate } from "react-router-dom";
import { companies, vehicleCategories } from "@/data/vehicleData";
import { ArrowLeft } from "lucide-react";

const Companies = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const list = companies[categoryId || ""] || [];
  const category = vehicleCategories.find(c => c.id === categoryId);

  return (
    <div className="container py-12">
      <button onClick={() => navigate("/")} className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 text-sm transition-colors">
        <ArrowLeft size={16} /> Back
      </button>
      <h1 className="text-3xl font-semibold mb-2">Select Company.</h1>
      <p className="text-muted-foreground mb-8">{category?.name} — Choose a manufacturer</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {list.map((co, i) => (
          <button
            key={co.id}
            onClick={() => navigate(`/models/${co.id}`)}
            className="bg-card rounded-xl p-6 text-center card-hover animate-fade-in"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <h2 className="text-lg font-semibold">{co.name}</h2>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Companies;
