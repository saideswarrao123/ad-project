import { useParams, useNavigate } from "react-router-dom";
import { models } from "@/data/vehicleData";
import { ArrowLeft } from "lucide-react";

const Models = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  const list = models[companyId || ""] || [];

  return (
    <div className="container py-12">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 text-sm transition-colors">
        <ArrowLeft size={16} /> Back
      </button>
      <h1 className="text-3xl font-semibold mb-2">Select Model.</h1>
      <p className="text-muted-foreground mb-8">Choose a vehicle model to view available parts</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {list.map((model, i) => (
          <button
            key={model}
            onClick={() => navigate("/products")}
            className="bg-card rounded-xl p-6 text-center card-hover animate-fade-in"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <h2 className="text-lg font-semibold">{model}</h2>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Models;
